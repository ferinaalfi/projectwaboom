﻿var XLSX = require('../');
var testCommon = require('./Common.js');

var file = 'חישוב_נקודות_זיכוי.xlsx';

describe(file, function () {
	testCommon(file);
});