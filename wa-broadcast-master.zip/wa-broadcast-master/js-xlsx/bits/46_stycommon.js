var styles = {}; // shared styles

var themes = {}; // shared themes

